// app/blogs/page.js
import { metadata } from "./metadata";
import BlogPage from "./blogpage";

export { metadata };

export default function BlogPagee() {
  return <BlogPage />;
}
